package controlefinanceiro.exception;

public class LoginInvalidoRNException extends RNException {

    private static final long serialVersionUID = 1L;

    public LoginInvalidoRNException() {
        super();
    }

    public LoginInvalidoRNException(String mes) {
        super(mes);
    }

}
