package controlefinanceiro.exception;

public class ErroEliminarRNException extends RNException {

    private static final long serialVersionUID = -6152302071403248951L;

    public ErroEliminarRNException(String mes) {
        super(mes);
    }

}
