package controlefinanceiro.exception;


@SuppressWarnings("serial")
public class CampoInvalidoRNException extends RNException {

    public CampoInvalidoRNException(String mes) {
        super(mes);
    }

}
