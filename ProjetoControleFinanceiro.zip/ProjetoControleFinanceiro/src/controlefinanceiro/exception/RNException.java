package controlefinanceiro.exception;

public class RNException extends Exception {
    private static final long serialVersionUID = 1L;

    public RNException(String mes) {
        super(mes);
    }

    public RNException() {
        super();
    }

}
