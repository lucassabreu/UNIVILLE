package controlefinanceiro.dao.entidade;

public enum SituacaoCheque {
    CADASTRADO, COMPENSADO, ESTORNADO
}
