package controlefinanceiro.dao.entidade;

public enum Natureza {
    DESPESA, RECEITA
}
