package br.edu.univille.main;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.Random;

import br.edu.univille.arvore.Arvore;

public class ExecutaArvore {

	public static void main(String[] args) throws Exception {
		int t = Integer.valueOf(args[0]);
		String clazz = args[1];
		geraValores(t);
		Integer[] valores = getValores("numeros" + t + ".txt");
		Arvore ab = (Arvore) Class.forName(clazz).newInstance();
		long t0 = System.currentTimeMillis();
		PrintStream out = new PrintStream(new File("saida" + t + ".txt"));
		for (Integer valor : valores) {
			ab.adicionaValor(valor);
		}
		ab.imprimirArvore(out);
		long t1 = System.currentTimeMillis();
		out.println(valores.length + " - " + (t1 - t0));
		out.flush();
		out.close();
	}

	private static Integer[] getValores(String arquivo) throws Exception {
		FileInputStream in = new FileInputStream(new File(arquivo));
		byte b[] = new byte[1024 * 5];
		ByteArrayOutputStream o = new ByteArrayOutputStream();
		int t = 0;
		while ((t = in.read(b)) > 0) {
			o.write(b, 0, t);
		}
		String s = new String(o.toByteArray());
		String[] valores = s.substring(1, s.length() - 1).split(",");
		Integer i[] = new Integer[valores.length];
		for (int j = 0; j < i.length; j++) {
			i[j] = Integer.valueOf(valores[j].trim());
		}
		return i;
	}

	private static Integer[] geraValores(int t) throws Exception {
		Integer[] valores = new Integer[t];
		for (int i = 0; i < valores.length; i++) {
			valores[i] = Integer.valueOf(i + 1);
		}
		shuffle(valores);
		FileOutputStream out = new FileOutputStream(new File("numeros" + t + ".txt"));
		out.write(Arrays.toString(valores).getBytes());
		out.flush();
		out.close();
		return valores;
	}

	private static void shuffle(Integer[] valores) {
		Random r = new Random();
		for (int i = 0; i < valores.length; i++) {
			int p = r.nextInt(valores.length);
			Integer t = valores[i];
			valores[i] = valores[p];
			valores[p] = t;
		}
	}

}
