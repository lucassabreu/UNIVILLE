package br.edu.univille.arvore;

import java.io.PrintStream;

public interface Arvore {

	void adicionaValor(Integer valor);
	
	void imprimirArvore(PrintStream out);
	
}
